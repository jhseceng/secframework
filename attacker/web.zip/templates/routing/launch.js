$(document).ready(function(){
    $('.launchbutton').on('click', function () {


    })
});